package com.ecommerce.test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FileUploadUsingAutoITDemo {

	public static void main(String[] args) throws InterruptedException, IOException {

		WebDriver driver =  new FirefoxDriver();
		demoFileUpload(driver);
		
		driver.close();
	}
	
	static void demoFileUpload(WebDriver driver) throws InterruptedException, IOException {
		
		//Actions actions = new actions(driver);
		
		driver.get("https://demoqa.com/automation-practice-form");

		Thread.sleep(10000);
		
	    driver.findElement(By.id("uploadPicture")).click();
	    
	    Thread.sleep(10000);
	    
	    Runtime.getRuntime().exec("C:\\temp\\Phase5Test.exe");
	    
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
}